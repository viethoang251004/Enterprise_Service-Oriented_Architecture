from sqlalchemy import Column, String
from database import Base

class Staff(Base):
    __tablename__ = 'staff'
    s_id = Column(String, primary_key=True, index=True)  # staff ID
    s_email = Column(String, index=True) # email address of the staff member
    s_name = Column(String, index=True)
    s_password = Column(String, index=True)
    s_role = Column(String, index=True)