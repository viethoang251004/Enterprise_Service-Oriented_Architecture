from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel
from typing import List, Annotated 
from database import engine, SessionLocal
from sqlalchemy.orm import Session
import model

app = FastAPI()

# create table and columns in postgres
model.Base.metadata.create_all(bind=engine)

class StaffBase(BaseModel):
    s_id: str
    email: str
    name: str
    password: str
    role: str

class StaffSignIn(BaseModel):
    s_id: str
    password: str

def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()   

db_dependency = Annotated[Session, Depends(get_db)]

# CREATE API END POINT
@app.get('/')
async def Home():
    return "Welcome to Sign In API"

@app.post("/sign-in")
async def signin(signin_data: StaffSignIn, db: db_dependency):
    staff = db.query(model.Staff).filter(model.Staff.s_id == signin_data.s_id).first()
    if staff is None: return  {"msg": "No such user"}
    if staff.s_password != signin_data.password: return  {"msg": "Wrong Password"}
    return {"id": staff.s_id, "name": staff.s_name, "role": staff.s_role} 
    