from fastapi import FastAPI
from redis_om import get_redis_connection, HashModel

from typing import Optional

app = FastAPI()

REDIS_DB = get_redis_connection(
    host='redis-11569.c61.us-east-1-3.ec2.redns.redis-cloud.com', 
    port=11569,
    password='HehgnRmbjiv1mGicB1LkUYOk3GeDcT5X',
    decode_responses=True
)

class Order(HashModel):
    order_date: str
    order_total: Optional[float] = 0.0
    staff_id: str
    table_no: int
    
    class Meta:
        database = REDIS_DB

# class SubOrder(HashModel):
#     session_id: str
#     order_id: str
#     status: str
#     items: Optional[dict]
    
#     class Meta:
#         database = REDIS_DB
    
@app.get("/")
async def home():
    return "ORDER SERVICE API"

@app.get("/orders")
def test_get_all_orders():
    return [format(pk) for pk in Order.all_pks()]

def format(pk: str):
    order = Order.get(pk)
    return {
        'order_id': order.pk,
        'order_date': order.order_date,
        'staff_id': order.staff_id,
        'table_no': order.table_no,
        
    }

@app.post("/order")
async def create_order(order: Order):
    return order.save()

@app.delete("/orders/{id}")
def get(id: str):
    return Order.delete(id)
