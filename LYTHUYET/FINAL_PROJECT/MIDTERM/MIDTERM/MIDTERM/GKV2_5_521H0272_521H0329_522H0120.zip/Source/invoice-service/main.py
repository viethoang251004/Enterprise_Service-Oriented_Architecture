from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel
from typing import List, Annotated 
from database import engine, SessionLocal
from sqlalchemy.orm import Session
import model
from typing import Dict, Any

app = FastAPI()

# create table and columns in postgres
model.Base.metadata.create_all(bind=engine)

class Invoice(BaseModel):
    invoiceID: str
    invoiceDate: str
    totalAmount: float
    tableNo: int
    staffID: str
    items: Dict[str, Any]

def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()    

@app.get('/')
async def Home():
    return "Welcome to Invoice API"