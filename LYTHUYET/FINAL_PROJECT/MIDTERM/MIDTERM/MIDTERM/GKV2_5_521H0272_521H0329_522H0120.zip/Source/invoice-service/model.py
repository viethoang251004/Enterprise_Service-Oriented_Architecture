from sqlalchemy import Boolean, Column, ForeignKey, String, FLOAT, INTEGER
from sqlalchemy.dialects.postgresql import JSONB
from database import Base

class Invoice(Base):
    __tablename__ = 'invoice'
    invoice_id = Column(String, primary_key=True, index=True)
    invoice_date = Column(String, index=True)
    total_amount = Column(FLOAT, index=True)
    table_no = Column(INTEGER, index=True)
    staff_id = Column(String, index=True)
    items = Column(JSONB, index=True)
    