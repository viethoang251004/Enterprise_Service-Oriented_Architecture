from fastapi import  FastAPI
from pymongo.mongo_client import MongoClient
from manage_menu import router

app = FastAPI()

app.include_router(router)