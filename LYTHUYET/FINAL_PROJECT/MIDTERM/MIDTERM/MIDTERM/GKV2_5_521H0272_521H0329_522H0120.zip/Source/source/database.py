from pymongo import MongoClient
client = MongoClient("mongodb+srv://admin:12345@cluster0.6m98ize.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
db = client.items_db
collection_name = db["item"]