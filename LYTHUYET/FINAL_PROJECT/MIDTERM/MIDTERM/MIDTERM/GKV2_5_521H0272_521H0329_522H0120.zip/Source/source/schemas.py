def individual_serial(item) -> dict:
    return {
        "item_id": str(item["_id"]),
        "name": item["name"],
        "description": item["description"],
        "price": item["price"],
        "is_available": item["is_available"],
        "image_link": item["image_link"] 
    } 

def list_serial(items) -> list:
    return [individual_serial(item) for item in items]