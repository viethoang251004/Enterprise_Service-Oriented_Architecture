from fastapi import APIRouter
from model import Item
from database import collection_name
from schemas import list_serial
from bson import ObjectId

router = APIRouter()


@router.get("/")
async def home(): return "Welcome to Manage Menu API"   

# Get  all items in the database
@router.get("/get-items")
async def get_items(): 
    items = list_serial(collection_name.find())
    return items

# post an item (Not Used)
@router.post("/add-item")
async def add_item(item: Item):  
    collection_name.insert_one(dict(item))

# update available status of an item by its id
@router.put("/update-status/{id}/")
async def update_status(id: str):
    try:
        _ = ObjectId(id)
    except Exception as e:
        return {"error": f"Invalid ID"}
    
    item = collection_name.find_one( {'_id':ObjectId(id)} )
    if item != None : 
        # change the status and save it back into the database
        collection_name.update_one({'_id':ObjectId(id)},{'$set':{"is_available":not bool(item['is_available'])}})
        return {"message":"Successfully updated!"}
    else:
        return {"error":"Item does not exist"}
        

