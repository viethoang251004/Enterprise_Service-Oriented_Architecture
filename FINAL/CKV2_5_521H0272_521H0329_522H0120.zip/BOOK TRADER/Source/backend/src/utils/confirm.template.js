'use strict'

const htmlEmailToken = () => {
    return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- <title>Confirm</title> -->
    </head>
    <body>
        <body style="font-family: 'Poppins', Arial, sans-serif;">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td align="center" style="padding: 20px;">
                        <table class="content" width="600" border="0" cellspacing="0" cellpadding="0" style="border-collapse: collapse; border: 1px solid #cccccc;">
                            <!-- Header -->
                            <tr>
                                <td class="header" style="padding: 20px; text-align: center; color: black; font-size: 30px; font-weight: bold;">
                                Mật khẩu đăng nhập tạm thời
                                </td>
                            </tr>
    
                            <tr>
                                <td style="text-align: center; padding-bottom: 10px;">
                                    <img src="assets/email_green_tick.jpg" width="150px" height="150px">
                                </td>
                            </tr>
        
                            <!-- Body -->
                            <tr>
                                <td class="body" style="padding-left: 40px; padding-right: 40px;  padding-bottom: 20px;text-align: center; font-size: 16px; line-height: 1.6;">
                                    Bạn đã đăng ký tài khoản trên <strong style="color: #eaae3f;">Booker</strong>.
                                    Mật khẩu tạm thời cho tài khoản của bạn là: <strong style="color: red;">{{password}}</strong> <br><br>
                                    Để thực hiện đăng nhập, hãy nhấn vào:
                                </td>
                            </tr>
        
                            <!-- Call to action Button -->
                            <tr>
                                <td style="padding: 0px 40px 0px 40px; text-align: center;">
                                    <!-- CTA Button -->
                                    <table cellspacing="0" cellpadding="0" style="margin: auto;">
                                        <tr>
                                            <td align="center" style="background-color: #ae8af7; padding: 10px 20px; border-radius: 5px;">
                                                <a href="http://localhost:3000" style="color: #ffffff; text-decoration: none; font-weight: bold;">Đến trang đăng nhập</a>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            
                            <!-- Footer -->
                            <tr>
                                <td class="footer" style=" padding: 40px; text-align: center; color: black; font-size: 14px;">
                                Copyright &copy; 2024 | Booker
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </body>
    </body>
    </html>
    `
}

module.exports = { htmlEmailToken }