module.exports = {
    StatusCodes: require('./statusCodes'),
    ReasonPhrases: require('./reasonPhrases')
}