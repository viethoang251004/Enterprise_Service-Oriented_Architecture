
// export function navigateToPage() {
//     console.log("XXXXXX");
//     alert("xxx")
// }

