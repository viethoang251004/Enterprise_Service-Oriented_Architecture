import re
from flask import Flask

app = Flask(__name__)

@app.route("/product/<regex('[A-Z]{3}-\d{3}'):product_id>")
def get_product(product_id):
    return f"Product ID: {product_id} is valid."

if __name__ == "__main__":
    app.run()