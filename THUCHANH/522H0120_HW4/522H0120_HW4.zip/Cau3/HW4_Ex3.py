from fastapi import FastAPI
app = FastAPI()

# Ex3
@app.get("/multiply/{num1}/{num2}")
def greet_user(num1:int, num2: int):
    return {"message": f"{num1*num2}"}