from fastapi import FastAPI
from enum import Enum

# Ex4
class Color(str, Enum):
    RED = "red"
    GREEN = "green"
    BLUE = "blue"

app = FastAPI()

@app.get("/favorite_color/{color}")
def favorite_color(color: Color):
    return {"message": f"Your favorite color is {color}"}