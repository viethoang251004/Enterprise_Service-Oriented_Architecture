from flask import Flask, request, jsonify

app = Flask(__name__)

# In-memory data structure to simulate database operations
users = {}

@app.route('/user/<id>', methods=['GET', 'PUT', 'DELETE'])
def user_operations(id):
    if request.method == 'GET':
        if id in users:
            return jsonify(users[id]), 200
        else:
            return jsonify({"error": "User not found"}), 404

    elif request.method == 'PUT':
        user_data = request.get_json()
        users[id] = user_data
        return jsonify({"message": "User updated successfully"}), 200

    elif request.method == 'DELETE':
        if id in users:
            del users[id]
            return jsonify({"message": "User deleted successfully"}), 200
        else:
            return jsonify({"error": "User not found"}), 404

if __name__ == '__main__':
    app.run(debug=True)
