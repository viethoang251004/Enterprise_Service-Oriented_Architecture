from flask import Flask, jsonify

app = Flask(__name__)

# In-memory data structure to simulate database operations
posts = {
    "1": {
        "title": "First Post",
        "comments": {
            "1": "Great post!",
            "2": "Thanks for sharing."
        }
    },
    "2": {
        "title": "Second Post",
        "comments": {
            "1": "Interesting read.",
            "2": "I learned a lot."
        }
    }
}

@app.route('/posts/<post_id>/comments/<comment_id>', methods=['GET'])
def get_comment(post_id, comment_id):
    if post_id in posts and comment_id in posts[post_id]["comments"]:
        return jsonify({"comment": posts[post_id]["comments"][comment_id]}), 200
    else:
        return jsonify({"error": "Post or comment not found"}), 404

if __name__ == '__main__':
    app.run(debug=True)

