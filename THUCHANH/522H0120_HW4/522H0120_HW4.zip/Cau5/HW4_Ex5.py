from fastapi import FastAPI

app = FastAPI()

# Ex5
@app.get("/hello/{name}")
def say_hello(name: str = "World"):
    return {"message": f"Hello, {name}!"}