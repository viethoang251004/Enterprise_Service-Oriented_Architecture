from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/hello/<language_code>/<name>', methods=['GET'])
def hello(language_code, name):
    greetings = {
        "en": f"Hello, {name}!",
        "es": f"Hola, {name}!",
        "fr": f"Bonjour, {name}!"
    }

    greeting = greetings.get(language_code, f"Hello, {name}!")
    return jsonify({"message": greeting}), 200

if __name__ == '__main__':
    app.run(debug=True)
