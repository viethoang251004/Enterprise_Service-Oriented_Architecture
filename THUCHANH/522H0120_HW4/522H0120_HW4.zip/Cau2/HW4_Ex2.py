from fastapi import FastAPI
app = FastAPI()

# Ex2
@app.get("/age/{age}")
def greet_user(age: int):
    if (age > 18):
        return {"message": f"Congratulations, you are an adult!"}
    else:
        return {"message": f"Sorry, you are not an adult."}