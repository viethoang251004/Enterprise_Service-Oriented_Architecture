from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/v1/greet/<name>', methods=['GET'])
def greet_v1(name):
    return jsonify({"message": f"Hello, {name}!"}), 200

@app.route('/v2/greet/<name>', methods=['GET'])
def greet_v2(name):
    greetings = {
        "English": f"Hello, {name}!",
        "Spanish": f"Hola, {name}!",
        "French": f"Bonjour, {name}!",
        "German": f"Hallo, {name}!",
        "Italian": f"Ciao, {name}!"
    }
    return jsonify(greetings), 200

if __name__ == '__main__':
    app.run(debug=True)
