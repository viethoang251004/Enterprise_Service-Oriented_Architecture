from fastapi import FastAPI, HTTPException
from datetime import datetime

app = FastAPI()

@app.get("/validate/{year}")
def validate_year(year: int):
    current_year = datetime.now().year

    if year < 1900 or year > current_year:
        raise HTTPException(status_code=400, detail="Invalid year")

    return {"message": "Year is valid"}