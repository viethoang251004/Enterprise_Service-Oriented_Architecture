import calendar
from flask import Flask

app = Flask(__name__)

@app.route("/day_status/<int:year>/<int:month>/<int:day>")
def get_day_status(year, month, day):
    try:
        weekday = calendar.weekday(year, month, day)
        if weekday < 5:
            return f"The day {day}/{month}/{year} is a weekday."
        else:
            return f"The day {day}/{month}/{year} is a weekend day."
    except ValueError:
        return "Invalid date."

if __name__ == "__main__":
    app.run()